from setuptools import find_packages, setup

setup(
    name="cex_service",
    version="1.0.1",
    packages=find_packages(),
)
