from setuptools import find_packages, setup

setup(
    name="exchange_services",
    version="1.0.1",
    packages=find_packages(),
)
