from setuptools import find_packages, setup

setup(
    name="cex_services",
    version="1.0.0",
    packages=find_packages(),
)
